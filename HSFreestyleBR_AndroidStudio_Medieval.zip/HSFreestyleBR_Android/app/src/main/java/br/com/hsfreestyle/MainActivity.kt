package br.com.hsfreestyle

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.draw.paint
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale
import kotlin.math.roundToInt

private val Bg = Color(0xE607110D)
private val Panel = Color(0xE60D1C16)
private val Green = Color(0xFF19C37D)
private val Yellow = Color(0xFFF5CF38)
private val Blue = Color(0xFF2784FF)
private val Muted = Color(0xFF91A59A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Green, secondary = Yellow, background = Bg,
                    surface = Panel, onPrimary = Bg, onBackground = Color.White,
                    onSurface = Color.White
                )
            ) {
                HSFreestyleApp(
                    onOpenDisplay = { safeOpen(Settings.ACTION_DISPLAY_SETTINGS) },
                    onOpenBattery = { safeOpen(Settings.ACTION_BATTERY_SAVER_SETTINGS) },
                    batteryInfo = { readBatteryInfo() }
                )
            }
        }
    }

    private fun safeOpen(action: String) {
        try {
            startActivity(Intent(action))
        } catch (_: Exception) {
            try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) { }
        }
    }

    @Suppress("DEPRECATION")
    private fun readBatteryInfo(): Pair<Int?, Float?> {
        val intent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val temp = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        val percent = if (level >= 0 && scale > 0) (level * 100f / scale).roundToInt() else null
        val celsius = if (temp >= 0) temp / 10f else null
        return percent to celsius
    }
}

private enum class Screen(val label: String) {
    PROFILE("Perfil"), SENSI("Sensi"), PERFORMANCE("Desempenho")
}

@Composable
private fun HSFreestyleApp(
    onOpenDisplay: () -> Unit,
    onOpenBattery: () -> Unit,
    batteryInfo: () -> Pair<Int?, Float?>
) {
    val prefs = androidx.compose.ui.platform.LocalContext.current
        .getSharedPreferences("hs_profile", Context.MODE_PRIVATE)
    var screen by remember { mutableStateOf(Screen.PROFILE) }
    var uid by remember { mutableStateOf(prefs.getString("uid", "") ?: "") }
    var nick by remember { mutableStateOf(prefs.getString("nick", "") ?: "") }
    var region by remember { mutableStateOf(prefs.getString("region", "Brasil") ?: "Brasil") }
    var profileSaved by remember { mutableStateOf(uid.isNotBlank()) }
    var status by remember { mutableStateOf("") }

    var style by remember { mutableStateOf("Equilibrado") }
    var dpi by remember { mutableStateOf("411") }
    var hz by remember { mutableIntStateOf(90) }
    var drag by remember { mutableFloatStateOf(2f) }
    var sensitivity by remember { mutableStateOf(listOf(184, 176, 168, 155, 90, 130, 48)) }

    var balance by remember { mutableFloatStateOf(50f) }
    var power by remember { mutableStateOf("Intermediário") }
    var heat by remember { mutableStateOf("Normal") }
    var plan by remember { mutableStateOf(listOf("Escolha suas preferências e gere um plano.")) }
    var battery by remember { mutableStateOf<Pair<Int?, Float?>>(null to null) }

    val context = androidx.compose.ui.platform.LocalContext.current
    LaunchedEffect(Unit) { battery = batteryInfo() }

    Column(
        modifier = Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0x99103021), Color(0xCC07110D), Color(0xE6050A08))))
            .paint(painterResource(id = R.drawable.brazil_flag_background), contentScale = ContentScale.Crop)
            .padding(14.dp)
    ) {
        Header()
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Screen.values().forEach { item ->
                NavigationChip(item, screen == item, Modifier.weight(1f)) { screen = item }
            }
        }
        Spacer(Modifier.height(12.dp))
        Column(
            modifier = Modifier.fillMaxSize().background(Panel, MaterialTheme.shapes.large)
                .padding(16.dp).verticalScroll(rememberScrollState())
        ) {
            when (screen) {
                Screen.PROFILE -> {
                    SectionTitle("IDENTIFICAÇÃO DO JOGADOR", "Perfil local • 🇧🇷")
                    Text(
                        "O UID serve para identificar o perfil dentro deste app. Ele não autentica a conta nem busca dados privados do jogo.",
                        color = Muted, fontSize = 12.sp
                    )
                    Spacer(Modifier.height(14.dp))
                    OutlinedTextField(
                        value = uid, onValueChange = { uid = it.filter(Char::isDigit).take(24) },
                        label = { Text("ID do jogador (UID)") }, placeholder = { Text("5 a 24 dígitos") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = nick, onValueChange = { nick = it.take(24) },
                        label = { Text("Apelido (opcional)") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    Text("Região da conta", color = Muted, fontSize = 12.sp)
                    var regionExpanded by remember { mutableStateOf(false) }
                    Box {
                        OutlinedButton(onClick = { regionExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                            Text(region); Spacer(Modifier.weight(1f)); Text("▾")
                        }
                        DropdownMenu(expanded = regionExpanded, onDismissRequest = { regionExpanded = false }) {
                            listOf("Brasil", "América do Sul", "América do Norte", "Europa", "Ásia", "Outra / não sei").forEach {
                                DropdownMenuItem(text = { Text(it) }, onClick = { region = it; regionExpanded = false })
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            if (uid.length !in 5..24) status = "Informe um UID numérico entre 5 e 24 dígitos."
                            else {
                                prefs.edit().putString("uid", uid).putString("nick", nick)
                                    .putString("region", region).apply()
                                profileSaved = true
                                status = "Perfil local salvo neste aparelho."
                            }
                        }, modifier = Modifier.fillMaxWidth()
                    ) { Icon(Icons.Default.Person, null); Spacer(Modifier.width(8.dp)); Text("SALVAR PERFIL") }
                    if (status.isNotBlank()) Text(status, color = Yellow, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                    Spacer(Modifier.height(16.dp))
                    InfoCard("RESUMO DO PERFIL") {
                        InfoRow("UID", if (profileSaved) uid else "—")
                        InfoRow("Apelido", nick.ifBlank { "Não informado" })
                        InfoRow("Região", region)
                        InfoRow("Estado", if (profileSaved) "Perfil local salvo" else "Aguardando cadastro")
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Nível, patente, partidas e estatísticas reais exigem uma API oficial/autorizada. Este app não inventa esses dados e não pede sua senha do jogo.",
                        color = Muted, fontSize = 11.sp
                    )
                }
                Screen.SENSI -> {
                    SectionTitle("CALCULADORA DE SENSIBILIDADE", "Sugestões de 0 a 200")
                    Text("Use os valores como ponto de partida e ajuste no modo treino.", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(12.dp))
                    ChoiceField("Estilo de jogo", style, listOf("Subir capa", "Rush", "Precisão", "Equilibrado")) { style = it }
                    OutlinedTextField(
                        value = dpi, onValueChange = { dpi = it.filter(Char::isDigit).take(4) },
                        label = { Text("DPI atual (informativo)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                    Text("Taxa de atualização selecionada", color = Muted, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(60, 90, 120, 144).forEach { rate ->
                            FilterChip(selected = hz == rate, onClick = { hz = rate }, label = { Text("$rate Hz") })
                        }
                    }
                    Text("Velocidade do arraste: ${listOf("Lenta", "Média", "Rápida")[(drag.roundToInt() - 1).coerceIn(0, 2)]}", color = Yellow)
                    Slider(value = drag, onValueChange = { drag = it }, valueRange = 1f..3f, steps = 1)
                    Button(onClick = {
                        val d = dpi.toIntOrNull()?.coerceIn(100, 1000) ?: 411
                        val styleOffset = when (style) { "Subir capa" -> 9; "Rush" -> 5; "Precisão" -> -10; else -> 0 }
                        val general = (178 + styleOffset + ((d - 411) / 22f).coerceIn(-9f, 12f) +
                            (if (hz >= 120) 3 else if (hz >= 90) 1 else -2) + (drag.roundToInt() - 2) * 7).roundToInt().coerceIn(0, 200)
                        sensitivity = listOf(general, (general - if (style == "Precisão") 12 else 5).coerceIn(0, 200),
                            (general - 13).coerceIn(0, 200), (general - 25).coerceIn(0, 200),
                            (general * .49f).roundToInt(), (general * .70f).roundToInt(),
                            (47 + (drag.roundToInt() - 2) * 3 + if (style == "Rush") 2 else 0).coerceIn(35, 60))
                    }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Tune, null); Spacer(Modifier.width(8.dp)); Text("CALCULAR SENSI") }
                    Spacer(Modifier.height(12.dp))
                    InfoCard("CONFIGURAÇÃO SUGERIDA") {
                        listOf("Geral", "Ponto vermelho", "Mira 2x", "Mira 4x", "AWM", "Olhadinha", "Botão de tiro").forEachIndexed { i, label ->
                            InfoRow(label, if (i == 6) "${sensitivity[i]}%" else sensitivity[i].toString())
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = {
                        val text = "HS FREESTYLE BR\\n" + listOf("Geral", "Ponto vermelho", "Mira 2x", "Mira 4x", "AWM", "Olhadinha", "Botão de tiro")
                            .mapIndexed { i, name -> "$name: ${sensitivity[i]}${if (i == 6) "%" else ""}" }.joinToString("\\n")
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("HS FREESTYLE", text))
                        status = "Configuração copiada para a área de transferência."
                    }, modifier = Modifier.fillMaxWidth()) { Text("COPIAR CONFIGURAÇÃO") }
                }
                Screen.PERFORMANCE -> {
                    SectionTitle("PAINEL DE DESEMPENHO", "Controles seguros do Android")
                    Text("Ajuste a prioridade e receba recomendações. Este app não força FPS nem altera configurações protegidas em segundo plano.", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(12.dp))
                    Text("Prioridade: ${when { balance <= 20 -> "Máxima fluidez"; balance <= 40 -> "Fluidez"; balance <= 60 -> "Equilíbrio"; balance <= 80 -> "Qualidade"; else -> "Máxima qualidade" }}", color = Yellow, fontWeight = FontWeight.Bold)
                    Slider(value = balance, onValueChange = { balance = it }, valueRange = 0f..100f, steps = 9)
                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("Fluidez", color = Green, fontSize = 11.sp); Text("Qualidade visual", color = Blue, fontSize = 11.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    ChoiceField("Potência do aparelho", power, listOf("Básico", "Intermediário", "Avançado")) { power = it }
                    ChoiceField("Temperatura percebida", heat, listOf("Normal", "Morno", "Muito quente")) { heat = it }
                    Button(onClick = {
                        val list = mutableListOf<String>()
                        if (balance <= 30) {
                            list += "No jogo, prefira gráficos Suave/Baixo e FPS estável."
                            list += "Feche apps que não estiver usando antes de jogar."
                        } else if (balance >= 70) {
                            list += "Teste gráficos mais altos se o FPS continuar estável."
                            list += "Se houver travamentos, reduza efeitos visuais primeiro."
                        } else {
                            list += "Comece com gráficos Padrão e ajuste uma opção por vez."
                            list += "Escolha a taxa de quadros mais alta que permaneça estável."
                        }
                        if (power == "Básico") list += "Em aparelho básico, evite gravação de tela e multitarefa durante o jogo."
                        if (power == "Avançado") list += "Aumente efeitos gradualmente e monitore estabilidade."
                        if (heat == "Muito quente") list += "Faça uma pausa e deixe o aparelho esfriar antes de voltar a jogar."
                        else if (heat == "Morno") list += "Se a temperatura subir, reduza gráficos e evite jogar carregando."
                        else list += "Mantenha o sistema atualizado e o armazenamento com espaço livre."
                        list += "Não altere DPI ou menor largura sem anotar o valor original."
                        plan = list
                    }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Bolt, null); Spacer(Modifier.width(8.dp)); Text("GERAR PLANO") }
                    Spacer(Modifier.height(12.dp))
                    InfoCard("RECOMENDAÇÕES") { plan.forEachIndexed { i, item -> Text("${i + 1}. $item", color = Color(0xFFD8E5DD), fontSize = 12.sp, modifier = Modifier.padding(vertical = 4.dp)) } }
                    Spacer(Modifier.height(12.dp))
                    InfoCard("ESTADO DO APARELHO") {
                        InfoRow("Android", "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
                        InfoRow("Bateria", battery.first?.let { "$it%" } ?: "Indisponível")
                        InfoRow("Temperatura da bateria", battery.second?.let { String.format(Locale.getDefault(), "%.1f °C", it) } ?: "Indisponível")
                        Text("A temperatura apresentada é a da bateria, não uma medição exata da CPU/GPU.", color = Muted, fontSize = 10.sp)
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(onClick = { battery = batteryInfo() }, modifier = Modifier.fillMaxWidth()) { Text("ATUALIZAR DADOS") }
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(onClick = onOpenDisplay, modifier = Modifier.fillMaxWidth()) { Text("ABRIR CONFIGURAÇÕES DE TELA") }
                    OutlinedButton(onClick = onOpenBattery, modifier = Modifier.fillMaxWidth()) { Text("ABRIR CONFIGURAÇÕES DE BATERIA") }
                    Text("Os atalhos abrem páginas do sistema; qualquer mudança é feita por você e depende do fabricante.", color = Muted, fontSize = 11.sp)
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("🇧🇷 HS FREESTYLE BR • Ferramenta local de recomendações", color = Muted, fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
    }
}

@Composable
private fun Header() {
    Column {
        Row(Modifier.fillMaxWidth().height(5.dp)) {
            Box(Modifier.weight(1f).fillMaxHeight().background(Color(0xFF168744)))
            Box(Modifier.weight(1f).fillMaxHeight().background(Yellow))
            Box(Modifier.weight(1f).fillMaxHeight().background(Blue))
        }
        Row(
            modifier = Modifier.fillMaxWidth().background(Panel).padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(46.dp)) {
                Text("◆", color = Yellow, fontSize = 45.sp)
                Text("●", color = Blue, fontSize = 18.sp)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("HS FREESTYLE BR", fontSize = 17.sp, fontWeight = FontWeight.Black)
                Text("SENSI • PERFORMANCE • PERFIL", fontSize = 9.sp, color = Green, letterSpacing = 1.sp)
            }
            Text("PRO", color = Yellow, fontWeight = FontWeight.Black, fontSize = 11.sp)
        }
        Row(Modifier.fillMaxWidth().height(4.dp)) {
            Box(Modifier.weight(1f).fillMaxHeight().background(Color(0xFF168744)))
            Box(Modifier.weight(1f).fillMaxHeight().background(Yellow))
            Box(Modifier.weight(1f).fillMaxHeight().background(Blue))
        }
    }
}

@Composable
private fun NavigationChip(item: Screen, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val icon = when (item) { Screen.PROFILE -> Icons.Default.Person; Screen.SENSI -> Icons.Default.Tune; Screen.PERFORMANCE -> Icons.Default.Bolt }
    Surface(
        onClick = onClick, modifier = modifier.height(64.dp),
        color = if (selected) Color(0x22F5CF38) else Panel,
        shape = MaterialTheme.shapes.medium,
        border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) Yellow.copy(alpha = .55f) else Green.copy(alpha = .18f))
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(icon, null, tint = if (selected) Yellow else Muted, modifier = Modifier.size(20.dp))
            Text(item.label, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (selected) Yellow else Muted)
        }
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String) {
    Text(title, color = Green, fontSize = 14.sp, fontWeight = FontWeight.Black)
    Text(subtitle, color = Yellow, fontSize = 11.sp, modifier = Modifier.padding(top = 3.dp, bottom = 8.dp))
}

@Composable
private fun InfoCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth().background(Bg, MaterialTheme.shapes.medium)
            .padding(13.dp)
    ) {
        Text(title, color = Green, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        content()
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
        Text(label, color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
        Text(value, color = Color(0xFFE8F3EC), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1.2f))
    }
}

@Composable
private fun ChoiceField(label: String, selected: String, choices: List<String>, onChoice: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Column {
        Text(label, color = Muted, fontSize = 12.sp)
        Box {
            OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                Text(selected); Spacer(Modifier.weight(1f)); Text("▾")
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                choices.forEach { choice ->
                    DropdownMenuItem(text = { Text(choice) }, onClick = { onChoice(choice); expanded = false })
                }
            }
        }
    }
}
