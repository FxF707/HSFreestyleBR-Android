# HS FREESTYLE BR — Android nativo

Projeto Android nativo em Kotlin + Jetpack Compose, direcionado a Android 13 ou superior (minSdk 26; targetSdk 35).

## Funcionalidades
- Perfil local por UID, apelido e região (SharedPreferences). Não autentica a conta do jogo.
- Calculadora de sensibilidade configurável.
- Plano de recomendações para priorizar fluidez ou qualidade visual.
- Leitura de nível de bateria e temperatura reportada pela bateria, quando disponível.
- Atalhos para configurações de tela e bateria do Android.
- Interface medieval em verde-musgo, dourado envelhecido e azul profundo, sem neon.
- Fundo texturizado da bandeira brasileira aplicado à interface; painéis escuros translúcidos preservam a leitura.

## Limitações importantes
Um app comum não pode mudar arbitrariamente DPI, taxa de atualização, resolução, FPS do jogo ou encerrar processos de outros apps. O aplicativo não tenta contornar permissões nem usa APIs não autorizadas. Os atalhos abrem as telas do sistema para o usuário decidir o que alterar.
O UID por si só não fornece nível, patente, estatísticas ou dados privados. Para isso, integre uma API oficial/autorizada e documentada. Não solicite a senha do jogo.

## Como abrir e compilar
1. Instale Android Studio recente (com JDK 17).
2. Descompacte o ZIP.
3. Android Studio > Open > selecione a pasta `HSFreestyleBR_Android`.
4. Aguarde a sincronização do Gradle e instale os componentes do SDK Android 35 se solicitados.
5. Conecte um dispositivo Android ou inicie um emulador.
6. Use Run para testar, ou Build > Build APK(s) para gerar um APK de debug.

O APK de debug normalmente fica em `app/build/outputs/apk/debug/app-debug.apk`.

## Pacote
`br.com.hsfreestyle`

## Privacidade
Os dados do perfil são armazenados localmente no aparelho. Não há servidor, telemetria, login remoto ou consulta a serviços externos neste projeto inicial.
